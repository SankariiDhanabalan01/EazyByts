package com.mywebsite.tourtravels.Repository;

import com.mywebsite.tourtravels.Model.TourDetails;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TourRepository extends JpaRepository<TourDetails, Long> {
}