package com.mywebsite.tourtravels.Service;

import com.mywebsite.tourtravels.Repository.TourRepository;
import com.mywebsite.tourtravels.Model.TourDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class TourService {
    @Autowired
    private TourRepository tourRepo;

    public TourDetails addNewData(TourDetails tourDetails){
        return tourRepo.save(tourDetails);
    }

    public List<TourDetails> getAvailableData() {
        return tourRepo.findAll();
    }

    public TourDetails updateData(TourDetails tourData, long id) {
        List<TourDetails> tourDetails = tourRepo.findAllById(Collections.singleton(id));
        TourDetails details = tourRepo.findById(id).get();
        if (!tourDetails.isEmpty()){
            details = tourDetails.get(0);
            details.setId(tourDetails.get(0).getId());
            details.setPackageDescription(tourData.getPackageDescription());
            details.setPackageName(tourData.getPackageName());
            details.setPackagePrice(tourData.getPackagePrice());
        }
        return tourRepo.save(details);
    }

    public void deleteData(long id){
        tourRepo.deleteById(id);
    }
}
