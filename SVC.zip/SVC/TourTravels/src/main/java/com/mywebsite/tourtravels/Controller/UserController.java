package com.mywebsite.tourtravels.Controller;


import com.mywebsite.tourtravels.Model.UserModel;
import com.mywebsite.tourtravels.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController()
@RequestMapping("/user")
public class UserController {

    @Autowired
    private UserService userService;

    @PostMapping(value = "/adduser")
    public UserModel AddNewUser(@RequestBody UserModel userModel){
        return userService.addUser(userModel);
    }

    @GetMapping(value = "/getuser/{id}")
    public UserModel GetOneUser(@PathVariable(value = "id") Integer id){
        return userService.getUser(id);
    }

    @PutMapping(value = "/update/{id}")
    public UserModel UpdateUser(@RequestBody UserModel userModel, @PathVariable(value = "id") Integer id){
        return userService.updateUser(userModel, id);
    }

    @DeleteMapping(value = "/delete/{id}")
    public String DeleteOneUser(@PathVariable(value = "id") Integer id){
        userService.deleteUser(id);
        return "Deleted User Successfully";
    }
}
