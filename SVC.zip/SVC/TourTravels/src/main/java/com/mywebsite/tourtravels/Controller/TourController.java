package com.mywebsite.tourtravels.Controller;

import com.mywebsite.tourtravels.Service.TourService;
import com.mywebsite.tourtravels.Model.TourDetails;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController()
@RequestMapping("/api")
public class TourController {

    @Autowired
    private TourService tourService;

    @GetMapping(value = "/get")
    public List<TourDetails> getData() {
        return tourService.getAvailableData();
    }

    @PostMapping(value = "/add")
    public TourDetails addData(@RequestBody TourDetails tourData) {
        return tourService.addNewData(tourData);
    }

    @PutMapping(value = "/update/{id}")
    public TourDetails updateData(@RequestBody TourDetails tourData, @PathVariable(value = "id") Integer id) {
        return tourService.updateData(tourData,id);
    }

    @DeleteMapping(value = "/delete/{id}")
    public String deleteData(@PathVariable(value = "id") int id) {
        tourService.deleteData(id);
        return "Deleted Successfully!";
    }

}
