package com.mywebsite.tourtravels.Model;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name="tourdetail")
@AllArgsConstructor
@NoArgsConstructor
public class TourDetails {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String packageName;
    private String packagePrice;
    private String packageDescription;
    private int packageCode;
}
