package com.mywebsite.tourtravels.Repository;

import com.mywebsite.tourtravels.Model.UserModel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<UserModel, Long> {
}
