package com.mywebsite.tourtravels.Service;

import com.mywebsite.tourtravels.Model.UserModel;
import com.mywebsite.tourtravels.Repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Collections;
import java.util.List;

@Service
public class UserService {

    @Autowired
    UserRepository userRepo;

    public UserModel getUser(long id){
        return userRepo.findById(id).get();
    }

    public UserModel addUser(UserModel userModel){
        return userRepo.save(userModel);
    }

    public UserModel updateUser(UserModel userModel, long id){
        List<UserModel> users = userRepo.findAllById(Collections.singleton(id));
        UserModel resultSet = userModel;
        if(!users.isEmpty()){
            resultSet.setId(users.get(0).getId());
        }
        return userRepo.save(resultSet);
    }

    public void deleteUser(long id){
        userRepo.deleteById(id);
    }
}
